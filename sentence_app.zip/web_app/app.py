# app.py

from flask import Flask, render_template, request
from model import load_model, predict_nli

app = Flask(__name__)

# Load the model at the start
model = load_model('best_sbert_model.pth')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        # Get the premise and hypothesis from the form input
        premise = request.form['premise']
        hypothesis = request.form['hypothesis']

        # Predict NLI label using the model
        result = predict_nli(model, premise, hypothesis)

        return render_template('index.html', premise=premise, hypothesis=hypothesis, result=result)

if __name__ == '__main__':
    app.run(debug=True)
