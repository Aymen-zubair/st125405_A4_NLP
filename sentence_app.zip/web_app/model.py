# model.py

import torch
from sentence_transformers import SentenceTransformer

# Load the custom model manually using PyTorch (since it's in .pth format)
def load_model(model_path='best_sbert_model.pth'):
    # Initialize the model architecture (here we assume you're using SentenceTransformer)
    model = SentenceTransformer('all-MiniLM-L6-v2')  # Replace with the appropriate pre-trained model

    # Load the saved state_dict
    state_dict = torch.load(model_path, map_location=torch.device('cpu'))

    # Load the state dict into the model
    model.load_state_dict(state_dict)
    
    # Set the model to evaluation mode
    model.eval()

    return model

# Function to encode sentences
def encode_sentences(model, sentences):
    return model.encode(sentences)

# Function to predict NLI (Natural Language Inference)
def predict_nli(model, premise, hypothesis):
    embeddings1 = encode_sentences(model, [premise])
    embeddings2 = encode_sentences(model, [hypothesis])

    # Compute cosine similarity between the embeddings
    cosine_similarity = torch.nn.functional.cosine_similarity(
        torch.tensor(embeddings1),
        torch.tensor(embeddings2)
    )

    if cosine_similarity > 0.75:
        return "Entailment"
    elif 0.25 < cosine_similarity <= 0.75:
        return "Neutral"
    else:
        return "Contradiction"
